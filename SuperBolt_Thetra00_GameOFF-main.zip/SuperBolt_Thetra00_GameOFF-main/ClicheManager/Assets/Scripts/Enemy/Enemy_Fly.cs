using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Enemy_Fly : Enemy
{

    //[SerializeField] bool hasWaypoints = true;
    //[SerializeField] Transform[] waypoints;


    //protected override void Start()
    //{
    //    base.Start();   
    //}

    //protected override void Update()
    //{
    //    base.Update();
    //}



    //protected override void Movement()
    //{
    //    base.Movement();
    //}

    //protected override void HeadJump(GameObject player)
    //{
    //    base.HeadJump(player);
    //}

    //protected override void AnimationUpdate()
    //{
    //    base.AnimationUpdate();
    //}

}
