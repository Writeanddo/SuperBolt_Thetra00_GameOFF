using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class PlayerEmote : MonoBehaviour
{

    [SerializeField] Sprite happy, sad, angry, cry, question;



}
