using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class P_Lightning : P_Bullet
{
    protected override void HitEnemy(GameObject obj)
    {
        base.HitEnemy(obj);
    }
}
