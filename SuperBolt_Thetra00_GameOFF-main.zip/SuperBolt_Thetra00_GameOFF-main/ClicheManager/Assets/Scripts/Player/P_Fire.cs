using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class P_Fire : P_Bullet
{
    protected override void HitEnemy(GameObject obj)
    {
        base.HitEnemy(obj);
    }
}
